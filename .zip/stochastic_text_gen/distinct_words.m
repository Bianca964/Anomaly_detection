
function retval = distinct_words (tokens)
  % TODO: Find unique strings HINT: unique

  retval = unique(tokens);

endfunction
