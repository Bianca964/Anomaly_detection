function retval = sample_n_words (text,  widx, kscvidx, k, stoch, word_set, n)
  % Sample word using sample_next_word from the last k elements of text (k-seq), ad it to the end of text
  % repeat n times
  % This function is not tested by the checker, it can be tested as a binus by running `run tema1_script.m`
  retval = text;
endfunction
