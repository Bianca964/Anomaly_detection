# Farcasanu Bianca-Ioana 313CAb

# TEMA 1 METODE-NUMERICE

# TASK 1 - ANOMALY-DETECTION

    # function [mean_values variances] = estimate_gaussian(X)
    Aceasta functie are rolul de a estima parametrii unei distributii
Gaussiene folosind datele dintr-o matrice X. Ea calculeaza media si variantele
distributiei pe baza datelor furnizate. Functia primeste o matrice X care
contine datele si returneaza doi vectori: mean_values (media) si
variances. 

    # function probability = gaussian_distribution(X, mean_value, variance)
    Aceasta functie realizeaza calculul densitatii de probabilitate
Gaussiene pentru un set de date dat, pe baza mediei si a variantei date ca
parametri. Functia primeste o matrice X de exemple, o valoare medie
(mean_value) si o matrice de varianta (variance) si returneaza un vector de
probabilitati corespunzatro fiecarui exemplu din setul de date. Prin
intermediul acestei functii pot determina probabilitatea ca un anumit exemplu
sa apartina unei distributii Gaussiene cu parametrii specificati. Aceasta
functie este o functie auxiliara de care ma folosesc in multivariante_gaussian.

    # function probabilities = multivariate_gaussian(X, mean_values, variances)
    Aceasta functie calculeaza probabilitatile pentru un set de date dat.
Prin intermediul unei iteratii asupra fiecarui exemplu din setul de date
functia apeleaza functia gaussian_distribution pentru a calcula probabilitatea
pentru fiecare punct in parte. Rezultatul este un vector de probabilitati
asociat fiecarui exemplu din setul de date. De asemenea, este folosita in
functia optimal_threshold.

    # function [false_pozitives, false_negatives, true_pozitives] =
check_predictions(predictions, truths)
    Aceasta functie calculeaza numarul pozitivelor false si adevarate, precum
si numarul negativelor false pe care le returneaza verificand pentru fiecare
in parte in ce categorie se incadreaza.

    # function [precision recall F1] = metrics(true_pozitives,
false_pozitives, false_negatives)
    Aceasta functie calculeaza parametrii necesari conform formulelor date.
Este folosita mai apoi pentru simplificare si organizare in functia
optimal_threshold.

    # function [best_epsilon best_F1 associated_precision associated_recall] =
optimal_threshold(truths, probabilities)
    Aceasta functie are rolul de a gasi pragul optim pentru selectarea
outlierilor intr-un set de date. Prin analiza probabilitatilor calculate
anterior si a adevarurilor (truths), functia determina pragul care
maximizeaza scorul F1. Functia returneaza cel mai bun prag gasit
(best_epsilon), scorul F1 asociat (best_F1), precizia corespunzatoare
(associated_precision) si acoperirea corespunzatoare (associated_recall).
Pentru a gasi pragul optim, functia imparte intervalul de probabilitati
in multe praguri mai mici, mai exact 1000 (asa e dat in enunt) si evalueaza
fiecare prag in raport cu scorul F1 obtinut din predictiile generate. Pragul
care maximizeaza scorul F1 este considerat cel mai bun prag.

# TASK 2 - KERNEL-REGRESSION

    # linear_kernel(); polynomial_kernel(); gaussian_kernel()
    Aceste functii implementeaza formulele specifice fiecareia, asa cum sunt
prezentate in enuntul temei.

    # function [X_train, y_train, X_pred, y_pred] =
split_dataset (X, y, percentage)
    Aceasta functie este realizata pentru a imparti setul de date primit ca
parametru in 2 subseturi(unul de testare si unul de antrenare) si este
folosita pentru a evalua corectitudinea si performanta modelului. Pentru
setul de antrenare : pentru x_train iau primele nr_train linii din matricea X,
iar pentru y_train iau primele nr_train elemente, urmand ca pentru setul de
testare sa iau restul din matricea X, respectiv restul din vectorul coloana y.

    # function [K] = build_kernel (X, f, f_param)
    Aceasta functie construieste matricea de kerneluri parcurand linie cu linie
matricea data ca parametru 'X' in 2 for-uri pentru a lua toate combinatiile
posibile de linii ale acesteia. Pe aceste perechi de date (de linii) aplica
functia furnizata cu cel de-al 3-lea parametru de asemenea specificat,
punand rezultatul in matricea finala K la indexul corespunzator.

    # function [L] = cholesky (A)
    Aceasta functie realizeaza descompunerea LU a matricei furnizate calculand
fiecare termen de pe diagonala principala, dupa care termenii de sub aceasta.
Matricea U (superior triunghiulara) este de fapt transpusa matricei L
(inferior triunghiulara).

    # function [P] = get_lower_inverse (L)
    Aceasta functie calculeaza inversa unei matrici inferior triunghiulare
prin prisma eliminarii gaussiene : normalizez elementul de pe diagonala
principala din matricea P impartind intreaga linie la valoarea
corespunzatoare din matricea L si actualizez matricea P prin scaderea
produsului dintre randul corespunzator din P si elementul corespunzator
din coloana lui L, din fiecare rand de sub diagonala principala.

    # function [a] = get_prediction_params (K, y, lambda)
    Aceasta functie realizeaza calcularea vectorului de coeficienti 'a'.
Se calculeaza in prealabil matricea auxiliara A a carei inversa este aflata
prin cele 2 functii implementate anterior: se descompune A prin algoritmul
Cholesky in L * L', se calculeaza inversa lui L ca mai apoi sa se deteremine
inversa lui A de care avem nevoie pentru a calcula vectorul 'a' conform
formulei.

    # function [x] = conjugate_gradient (A, b, x0, tol, max_iter)
    Aceasta functie are scopul de a gasi solutia sistemului liniar Ax=b prin
minimizarea normei reziduului (principalul obiectiv). Incep cu aproximarea 
intiala a reziduului. La fiecare iteratie caut 
o directie de deplasare (p) si un pas de deplasare (alpha) astfel incat sa 
reduc cat mai mult norma reziduului. Actualizand reziduul in fiecare iteratie 
realizez ajustarea la noua solutie x. Verific de fiecare data, deopotriva,
daca toleranta a fost atinsa pentru a ma opri, daca nu este atinsa niciodata
se itereaza pana la max_iter.

    # function [a] = get_prediction_params_iterative (K, y, lambda)
    Aceasta functie realizeaza acelasi lucru ca si get_prediction_params()
dar printr-o metoda iterativa. Calculeaza matricea A si vectorul coloana b
in functie de datele primite ca parametru ca mai apoi sa afle matricea de
coeficienti 'a' prin intermediul functiei conjugate_gradient().

    # function pred = eval_value(x, X, f, f_param, a)
    In aceasta functie se parcurg toti vectorii de intrare folositi pentru
a antrena modelul (stocati in matricea X), iar pentru fiecare punct de
antrenare se calculeaza valoarea kernelului intre vectorul de intrare x si
punctul de antrenare respectiv. Valoarea kernelului este apoi ponderata cu
parametrul corespunzator din vectorul coloana 'a' si adaugata la valoarea
estimata 'pred'. Astfel, 'pred' este suma ponderata a valorilor kernelului
intre 'x' si toate punctele de antrenare, utilizand parametrii de predictie
din vectorul 'a'. In final, 'pred' va stoca valoarea estimata pentru vectorul
de intrare 'x' in fucntie de modelul specificat.

# TASK 3 - STOCHASTIC_TEXT_GENERATOR

    # function retval = distinct_words (tokens)
    Aceasta functie returneaza vectorul de cuvinte sortat in ordine
lexicografica si din care s-au eliminat duplicatele (adica au ramas
doar cuvintele unice). Folosesc functia unique care face ambele lucruri
simultan.

    # function B = k_secv (A, k)
    Aceasta functie realizeaza concatenarea secventelor k cate k din vectorul
A, punand sirurile concatenate in cell-array-ul B la indexul corespunzator.

    # function unique_cell_array = distinct_k_secv (cell_array)
    Aceasta functie intoarce cell_array-ul dupa ce se elimina duplicatele.

    # function retval = word_idx (distinct_wds)
    Aceasta functie realizeaza un fel de hash-map intre vectorul
de cuvinte primit ca parametru si un vector de indici pe care sa le atribui.
Vectorul de indici va fi de fapt numarul cuvantului de oridne in cazul de fata.

    # function retval = k_secv_idx (distinct_k_sec)
    Aceasta functie realizeaza legatura dintre secvente si indecsi, la fel
ca in cadrul functiei word_idx (urmeaza acelasi algoritm).

    # function retval = stochastic_matrix (k_secv_corpus, corpus_words,
                                           words_idx, k_secv_idx, k)
    Aceasta functie construieste matricea stocastica cu nr_secv linii si 
nr_words coloane provenite dupa eliminarea duplicatelor din seturile de cuvinte
si secvente. Obtin indicii cuvintelor din vectorul de cuvinte initial deplasati
cu k pozitii in fata si il extind cu zero-uri pentru a pastra aceeasi
dimensiune cu word_idx. Mai apoi, parcurg fiecare element din vectorul
ksecv_idx si verific daca elementul corespunzator din shifted_words_indices
este diferit de 0 (daca e 0 inseamna ca nu trebuie sa-l bag in seama intrucat
acel 0 a fost adaugat ca padding). Daca conditia if este indeplinita,
actualizez matricea stocastica la poziitia corespunzatoare, adica incremenetz
valoarea de la randul ksecv_idx(i) si coloana shifted_word_indices(i) a
matricei stocastice cu 1 (am mai gasit o aparitie).
Per total, functia contorizeaza numarul de aparitii ale cuvintelor care
urmeaza fiecare secventa k.
